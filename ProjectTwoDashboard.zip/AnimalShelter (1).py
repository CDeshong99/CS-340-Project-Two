from pymongo import MongoClient
import pandas as pd
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self):
        # Connection Variables
        USER = 'aacuser'
        PASS = 'SNHU1234'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 30153
        DB = 'AAC'
        COL = 'animals'

        # Initialize MongoDB connection
        self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}')
        self.database = self.client[DB]
        self.collection = self.database[COL]

    def create(self, data):
        """Insert a single document into the collection"""
        if data is not None:
            result = self.collection.insert_one(data)
            return result.acknowledged
        else:
            raise Exception("Nothing to save, data parameter is empty")

    def read(self, query={}):
        """Query documents from the collection and always return a list"""
        if not isinstance(query, dict):
            query = {}
        try:
            results = list(self.collection.find(query))
            return results
        except Exception as e:
            print(f"Error in read(): {e}")
            return []

    def bulk_import_csv(self, filepath):
        """Load and insert multiple documents from a CSV file"""
        try:
            df = pd.read_csv(filepath)
            data = df.to_dict(orient='records')
            result = self.collection.insert_many(data)
            return len(result.inserted_ids)
        except Exception as e:
            print("Failed to import CSV:", str(e))
            return 0




